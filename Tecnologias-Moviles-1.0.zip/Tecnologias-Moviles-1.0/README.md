﻿# Tecnologias-Moviles
Trabajo materia tecnologías móviles
Nicolas

Lista de usuarios que se registraron (un nombre por linea).
/ListaUsuarios.txt

Usuarios que se mantiene la sesión(solo el nombre).
/loggedSession.txt

Carpeta de usuario
/{nombre de usuario}/

Datos de usuario
/{nombre de usuario}/datos.txt

Configuración del usuario
/{nombre de usuario}/config.txt

